__version_info__ = ('1', '5', '2')
__version__ = '.'.join(__version_info__)
